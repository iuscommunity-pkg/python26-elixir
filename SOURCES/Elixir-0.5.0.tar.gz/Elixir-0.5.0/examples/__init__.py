'''
========
Examples
========

Contains various example projects.
'''